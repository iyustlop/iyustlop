TestRail API 
------------

This repository contains several example bindings on how to access TestRail's API (v2).
You can learn more about TestRail's API here:

http://docs.gurock.com/testrail-api2/start

-- 
Copyright Gurock Software GmbH. See license.md for details.

http://www.gurock.com/
