TestRail API Binding for PHP
----------------------------
 
You can learn more about TestRail's API and how to use the PHP binding here:

http://docs.gurock.com/testrail-api2/start

http://docs.gurock.com/testrail-api2/bindings-php
