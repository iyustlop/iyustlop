TestRail API Binding for Java
-----------------------------
 
You can learn more about TestRail's API and how to use the Java binding here:

http://docs.gurock.com/testrail-api2/start

http://docs.gurock.com/testrail-api2/bindings-java

The binding uses the JSON.simple library for encoding/decoding JSON data, copyright Yidong Fang, licensed under the Apache 2.0 license and available here:

https://code.google.com/p/json-simple/
